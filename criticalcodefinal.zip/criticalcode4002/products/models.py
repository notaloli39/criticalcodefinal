from django.db import models


class Product(models.Model):  # database table for storing my items
    objects = None
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)  # 2083 is max character for urls


class Coupon(models.Model):  # database table for storing coupons
    code = models.CharField(max_length=8)
    description = models.CharField(max_length=255)
    discount = models.FloatField()


class Tkit(models.Model):  # database table for storing only turbochargers
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)


class Skit(models.Model):  # database table for storing only supercharger kits
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)


class Allpage(models.Model):  # database table for storing only supercharger kits
    name = models.CharField(max_length=255)
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)




