from django.apps import AppConfig


class ProductsConfig(AppConfig):
    name = 'products'


class TkitsConfig(AppConfig):
    name = 'tkits'


class SkitsConfig(AppConfig):
    name = 'skits'
