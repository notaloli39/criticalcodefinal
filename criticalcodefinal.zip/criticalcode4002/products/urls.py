from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),  # main page root path
    path('tkit', views.tkit),  # only turbocharger page
    path('skit', views.skit),  # only supercharger page
    path('allpage', views.index), # all kits
]
