from django.contrib import admin
from .models import Product, Coupon, Tkit, Skit, Allpage


class CouponAdmin(admin.ModelAdmin):
    list_display = ('code', 'discount')


class ProductAdmin(admin.ModelAdmin):  # managing common model within the admin area
    list_display = ('name', 'price', 'stock')  # displaying on site


class TKitAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')


class SKitAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')


class AllpageAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'stock')


# Register your models here.
admin.site.register(Product, ProductAdmin)  # managing your products in the admin page
admin.site.register(Coupon, CouponAdmin)
admin.site.register(Tkit, TKitAdmin)
admin.site.register(Skit, SKitAdmin)
admin.site.register(Allpage, AllpageAdmin)
