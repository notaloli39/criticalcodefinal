from django.http import HttpResponse
from django.shortcuts import render
from .models import Product, Tkit, Skit, Allpage


def index(request):  # page request for webserver
    products = Product.objects.all()
    return render(request, 'index.html',
                  {'products': products})  # rendering your html page


def tkit(request):
    tkits = Tkit.objects.all()
    return render(request, 'tkit.html',
                  {'tkits': tkits})


def skit(request):
    skits = Skit.objects.all()
    return render(request, 'skit.html',
                  {'skits': skits})


def allpage(request):
    allpages = Allpage.objects.all()
    return render(request, 'allpage.html',
                  {'allpages': allpages})
